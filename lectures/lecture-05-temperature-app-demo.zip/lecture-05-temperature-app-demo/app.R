library(shiny)
library(plotly)
library(ggplot2)
library(dplyr)
library(lubridate)
library(bomrang)
library(ozmaps)
library(glue)
theme_set(theme_classic())


# map data ----------------------------------------------------
oz_sf <- ozmap_data("states") %>%
  mutate(state = case_when(
    NAME=="New South Wales" ~ "NSW",
    NAME=="Victoria" ~ "VIC",
    NAME=="Queensland" ~ "QLD",
    NAME=="South Australia" ~ "SA",
    NAME=="Western Australia" ~ "WA",
    NAME=="Tasmania" ~ "TAS",
    NAME=="Northern Territory" ~ "NT",
    NAME=="Australian Capital Territory" ~ "ACT",
    TRUE ~ "OT"
  ))

# stations data -----------------------------------------------------------

load(system.file("extdata", "JSONurl_site_list.rda", package = "bomrang"))
stations <- JSONurl_site_list %>% filter(state!="ANT")
rm("JSONurl_site_list")



# ui ----------------------------------------------------------------------

ui <- fluidPage(
  br(),
  sidebarLayout(
    sidebarPanel(
      selectInput("state", "Which state do you want to examine?",
                  choices = c("ACT", "NSW", "NT", "QLD", "SA", "TAS", "VIC", "WA"),
                  selected = "VIC"),
      selectInput("station", "What station?", choices = ""),
      plotlyOutput("map")
    ),
    mainPanel(
      plotlyOutput("temp_vs_time"))
  ),
  includeCSS("styles.css")
)


# server ------------------------------------------------------------------

server <- function(input, output, session) {

  weather_data <- reactive(get_current_weather(input$station))

  observeEvent(event_data("plotly_click"), {
    click_df <- event_data("plotly_click")
    station <- filter(stations, lon==click_df$x, lat==click_df$y) %>%
      pull(name)
    updateSelectInput(session, "station", selected = station)
  })

  observeEvent(input$state, {
    updateSelectInput(session, "station",
                      choices = filter(stations, state==input$state)$name)
  })

  output$map <- renderPlotly({

    state_df <- filter(stations, state==input$state)

    plot_state <- ggplot() +
      geom_sf(data = filter(oz_sf, state==input$state)) +
      geom_point(data = state_df,
                 aes(lon, lat, label = name), color = "red") +
      theme_void() +
      theme(axis.line = element_blank(),
            panel.background = element_rect(fill = "transparent"),
            plot.background = element_rect(fill = "transparent", color = NA))

    ggplotly(plot_state) %>%
      config(displayModeBar = F) %>%
      style(text = state_df$name, traces = 3)

  })

  output$temp_vs_time <- renderPlotly({

    df <- weather_data() %>%
      mutate(text = glue("<b>Date</b>: {date(local_date_time_full)}
                         <b>Time</b>: {format(local_date_time_full, format = '%H:%M')}
                         <b>Temperature:</b> {air_temp}°C"))

    day_df <-   df %>%
      mutate(day = date(local_date_time_full)) %>%
      group_by(day) %>%
      summarise(min = min(local_date_time_full),
                max = max(local_date_time_full),
                mid = min + (max - min)/2) %>%
      mutate(fill = rep(c("white", "#e3e3e3"), length.out = n()))

    plot_temperature <- ggplot(df, aes(local_date_time_full, air_temp)) +
      # this doesn't show up on plotly
      # geom_rect(data = day_df, inherit.aes = FALSE,
      #          aes(ymin = -Inf, ymax = Inf, xmin = min, xmax = max, fill = I(fill))) +
      geom_text(data = day_df, aes(x = mid, y = -4, label = day),
                color = "gray") +
      ylim(-4, max(df$air_temp)) +
      geom_line(color = "yellow")  +
      scale_x_datetime(date_breaks = "6 hour", date_labels = "%l%p",
                       date_minor_breaks = "1 hour") +
      theme(axis.title.x = element_text(margin = margin(t = 25)),
            panel.background = element_rect(fill = "transparent"),
            plot.background = element_rect(fill = "transparent", color = NA),
            text = element_text(color = "white"),
            axis.line = element_line(color = "white"),
            axis.text = element_text(color = "white"))+
      labs(x = "Time", y = "Temperature (°C)", title = input$station)

    ggplotly(plot_temperature, source = "B") %>%
      config(displayModeBar = F) %>%
      style(hoverinfo = "none", traces = 1) %>%
      style(text = df$text, traces = 2)
  })

}

shinyApp(ui, server)


# runApp(display.mode = "showcase")
